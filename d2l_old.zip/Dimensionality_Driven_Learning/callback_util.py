import numpy as np
import keras.backend as K
from keras.utils import np_utils
from keras.callbacks import Callback
from keras.optimizers import SGD
from util import get_lids_random_batch
from loss import cross_entropy, sample_wise_lid, dataset_wise_lid

class RelabelCallback(Callback):
    def __init__(self, model, X_train, y_train, dataset, noise_ratio, verbose=1):
        super(RelabelCallback, self).__init__()
        self.validation_data = None
        self.model = model
        self.min_epoch = None
        self.X_train = X_train
        self.y_train = y_train
        self.dataset = dataset
        self.noise_ratio = noise_ratio
        self.lids = []
        self.verbose = verbose

    def on_epoch_end(self, epoch, logs={}):
        lid = np.mean(get_lids_random_batch(self.model, self.X_train[:1280], k=20, batch_size=128))
        self.lids.append(lid)
        print(self.lids)
        print('--Epoch: %s, LID: %.2f' % (epoch, lid))
        if self.verbose > 0:
            print('--Epoch: %s, LID: %.2f' % (epoch, lid))
        if self.found_turning_point(self.lids):
            self.relabel()
        return

    def found_turning_point(self, lids):
        if len(lids) > 5:
            # find lowest lid in the past 3 epochs
            if (lids[-1] - min(lids[-5:]) > np.std(lids[-5:])) & (self.min_epoch != lids.index(min(lids[-5:]))):
                print('--Found epoch with minimum LID at epoch: %s' % lids.index(min(lids[-5:])))
                self.min_epoch = self.lids.index(min(self.lids[-5:]))
                return True
        return False

    def relabel(self):
        # relabel to the epoch with min_lid
        min_model_path = 'model/lid_relabel/%s_%s.%02d.hdf5' % (self.dataset, self.noise_ratio, self.min_epoch + 1)
        self.model.load_weights(min_model_path)
        y_pred = np.argmax(self.model.predict(self.X_train, batch_size=128, verbose=0), axis=1)
        self.y_train[:] = np_utils.to_categorical(y_pred, num_classes=self.y_train.shape[1])


class LIDPaceCallback(Callback):
    def __init__(self, model, X_train, y_train, dataset, noise_ratio, epochs=150, 
                 pace_type='lid_dataset', init_epoch=10, epoch_win=5, verbose=1):
        super(LIDPaceCallback, self).__init__()
        self.validation_data = None
        self.model = model
        self.turning_epoch = -1
        self.X_train = X_train
        self.y_train = y_train
        self.dataset = dataset
        self.noise_ratio = noise_ratio
        self.epochs = epochs
        self.pace_type = pace_type
        self.mean_lid = -1.
        self.lids = []
        self.p_lambda = 0.
        self.init_epoch = init_epoch
        self.epoch_win = epoch_win
        self.verbose = verbose

    def on_epoch_end(self, epoch, logs={}):
        lid = np.mean(get_lids_random_batch(self.model, self.X_train[:1280], k=20, batch_size=128))
        self.p_lambda = epoch*1./self.epochs
        # to avoid nan
        if lid > 0:
            self.lids.append(lid)
        else:
            self.lids.append(self.lids[-1])
        print(self.lids)
        print('--Epoch: %s, LID: %.2f, mean LID: %.2f, turning epoch: %s' % (epoch, lid, self.mean_lid, self.turning_epoch))
        if self.verbose > 0:
            print('--Epoch: %s, LID: %.2f, mean LID: %.2f, turning epoch: %s' % (epoch, lid, self.mean_lid, self.turning_epoch))
        # find the turning point where to apply lid-paced learning strategy
        if self.found_turning_point(self.lids):
            self.update_learning_pace()
        return

    def found_turning_point(self, lids):
        if len(lids) > self.init_epoch + self.epoch_win:
            if self.turning_epoch > -1: # if turning point is already found, stop updating the mean LID
                return True
            else:
                self.mean_lid = np.mean(self.lids[-self.epoch_win-1:-1])
                if lids[-1] - self.mean_lid > np.std(lids[-self.epoch_win-1:-1]):
                    # self.turning_epoch = self.lids.index(min(self.lids[-self.epoch_win-1:-1]))
                    self.turning_epoch = len(lids) - 2 # roll back to previous non-overfitting status
                    print('--Found turning epoch: %s' % self.turning_epoch)
                    # rollback model
                    min_model_path = 'model/%s/%s_%s.%02d.hdf5' % (self.pace_type,
                                                                   self.dataset,
                                                                   self.noise_ratio,
                                                                   self.turning_epoch)
                    self.model.load_weights(min_model_path)
                    return True
        else:
            return False

    def update_learning_pace(self):
        sgd = SGD(lr=0.01, decay=1e-4, momentum=0.9)
        if self.pace_type == 'lid_sample':
            self.model.compile(loss=sample_wise_lid(self.model.layers[-2].output,
                                                     # min_lid=np.min(self.lids),
                                                     min_lid=self.mean_lid,
                                                    current_lid=self.lids[-1]),
                               optimizer=sgd, metrics=['accuracy'])
        elif self.pace_type == 'lid_dataset':
            self.model.compile(loss=dataset_wise_lid(self.model.layers[-1].output,
                                                     # min_lid=np.min(self.lids),
                                                     min_lid=self.mean_lid,
                                                     current_lid=self.lids[-1],
                                                     p_lambda=self.p_lambda),
                               optimizer=sgd, metrics=['accuracy'])
        else:
            self.model.compile(loss=cross_entropy,
                               optimizer=sgd, metrics=['accuracy'])

    def found_turning_point_2(self, lids):
        if len(lids) > 5:
            if self.turning_epoch > -1: # if turning point is already found, stop updating the mean LID
                return True
            else:
                self.mean_lid = np.mean(self.lids)
                if lids[-1] - self.mean_lid > np.std(lids):
                    self.turning_epoch = len(lids) - 1
                    print('--Found turning epoch: %s' % self.turning_epoch)
                    # rollback model
                    min_model_path = 'model/%s/%s_%s.%02d.hdf5' % (self.pace_type,
                                                                   self.dataset,
                                                                   self.noise_ratio,
                                                                   self.turning_epoch - 1)
                    self.model.load_weights(min_model_path)
                    return True
        else:
            self.mean_lid = np.mean(self.lids)
        return False

    def update_learning_pace_2(self):
        sgd = SGD(lr=0.1, momentum=0.9)
        if self.pace_type == 'lid_sample':
            self.model.compile(loss=sample_wise_lid(self.model.layers[-2].output,
                                                    min_lid=np.min(self.lids),
                                                    current_lid=self.lids[-1]),
                               optimizer=sgd, metrics=['accuracy'])
        elif self.pace_type == 'lid_dataset':
            self.model.compile(loss=dataset_wise_lid(self.model.layers[-1].output,
                                                     min_lid=np.min(self.lids),
                                                     current_lid=self.lids[-1],
                                                     p_lambda=self.p_lambda),
                               optimizer=sgd, metrics=['accuracy'])
            self.turning_epoch = len(self.lids) - 1
        else:
            self.model.compile(loss=cross_entropy,
                               optimizer=sgd, metrics=['accuracy'])


class EarlyStoppingByTrainAcc(Callback):
    """
    stops when train acc is above 0.99
    """

    def on_epoch_end(self, epoch, logs={}):
        train_acc = logs.get('acc')
        if train_acc > 0.99:
            self.model.stop_training = True
        return

class HistoryCallback(Callback):
    """
    Save test acc and loss
    """
    def __init__(self, model, X_test, y_test, dataset, model_name, noise_ratio,epochs):
        super(HistoryCallback, self).__init__()
        self.model = model
        self.X_test = X_test
        self.y_test = y_test
        self.dataset = dataset
        self.modle_name = model_name
        self.noise_ratio = noise_ratio
        self.epochs = epochs

        self.train_loss = []
        self.test_loss = []
        self.train_acc = []
        self.test_acc = []

    def on_epoch_end(self, epoch, logs={}):
        tr_acc = logs.get('acc')
        tr_loss = logs.get('loss')
        # val_loss = logs.get('val_loss')
        # val_acc = logs.get('val_acc')
        te_loss, te_acc = self.model.evaluate(self.X_test, self.y_test, batch_size=128, verbose=0)
        self.train_loss.append(tr_loss)
        self.test_loss.append(te_loss)
        self.train_acc.append(tr_acc)
        self.test_acc.append(te_acc)

        file_name = 'tmp/train_loss_%s_%s_%s.npy' % (self.modle_name, self.dataset, self.noise_ratio)
        np.save(file_name, np.array(self.train_loss))
        file_name = 'tmp/test_loss_%s_%s_%s.npy' % (self.modle_name, self.dataset, self.noise_ratio)
        np.save(file_name, np.array(self.test_loss))
        file_name = 'tmp/train_acc_%s_%s_%s.npy' % (self.modle_name, self.dataset, self.noise_ratio)
        np.save(file_name, np.array(self.train_acc))
        file_name = 'tmp/test_acc_%s_%s_%s.npy' % (self.modle_name, self.dataset, self.noise_ratio)
        np.save(file_name, np.array(self.test_acc))

        print('\n--Epoch %02d, train_loss: %.2f, train_acc: %.2f, test_loss: %.2f, test_acc: %.2f' %
              (epoch, tr_loss, tr_acc, te_loss, te_acc))
        return

import os
from shutil import copyfile

src = 'model/backward/cifar-10_100.38.hdf5'

for i in range(39, 120):
    dst = 'model/backward/cifar-10_100.%02d.hdf5'%i
    copyfile(src, dst)
